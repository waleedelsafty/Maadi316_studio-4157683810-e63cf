// This file is no longer needed and will be replaced by the new Firebase provider structure.
// To avoid breaking existing imports immediately, we'll leave it empty.
// It can be safely deleted after all components are updated to use the new hooks from `@/firebase`.
export {};
